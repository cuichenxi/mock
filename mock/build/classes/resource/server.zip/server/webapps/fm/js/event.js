function showConnTip(){
	var x,y; 
	x = event.clientX; 
	y = event.clientY; 
	 $("#usbConnTip").css({"left":x});
	 $("#usbConnTip").css({"top":y});
	document.getElementById("usbConnTip").innerHTML = "<label style=\"color:#ff8c00;font-size:12px;\">点击前保证手机通过数据线连接在电脑上</label>"; 
	document.getElementById("usbConnTip").style.display = "block"; 
}

function hideConnTip(){
	document.getElementById("usbConnTip").innerHTML = ""; 
	document.getElementById("usbConnTip").style.display = "none"; 
}