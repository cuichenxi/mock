/**
 * Created by WYM on 2016/4/12.
 */

/*树控件*/
var setting = {
    /* check: {
     enable: true
     },*/
    edit: {
        enable: true
    },
    data: {
        simpleData: {
            enable: true
        }
    },
    callback: {
        onClick: onClick,
        onCheck: onCheck,
        beforeRename:beforeRename,
        onRename:onRename,
        onRemove:onRemove,
        beforeDrag: beforeDrag
    }
};
var zNodes;

var nowJsonName="无";
function onClick(event, treeId, treeNode, clickFlag) {
    nowJsonName = treeNode.name;
    getJsonData(treeNode.name);
}
function getJsonData(name){
    $.ajax({
        type: "post",
        data: "requestTag=" + name,
        url: "getMockJson",
        dataType: "json",
        error: function (err) {
            outLog("错误");
        },
        success: onGetJsonDataSuccess
    })
}
function onGetJsonDataSuccess(data){
    $("#currtJson").text(nowJsonName);
    outLog("当前接口"+nowJsonName);
    editor.set(data);
}
function onCheck(e, treeId, treeNode) {
    alert("选中的节点名称："+treeNode.name);
}
function beforeRename(treeId, treeNode, newName, isCancel){
    $.ajax({
        type: "post",
        data: "funcTag=rename&oldName="+treeNode.name+"&newName="+newName,//发送到服务器的数据
        url: "jsonFileProcess",
        dataType: "text",
        error: function (err) {
            outLog("错误"+err);
        },
        success: onRenameSuccess(treeNode.name,newName)
    })
}
function onRenameSuccess(oldName,newName){
    setCurrtJsonName(newName);
    outLog("修改json文件名称成功  oldName:"+oldName+" newName:"+newName);
}
function onRename(event, treeId, treeNode, isCancel){
    outLog("onRename");
}
function onRemove(event, treeId, treeNode){
    $.ajax({
        type: "post",
        data: "funcTag=remove&name="+treeNode.name,
        url: "jsonFileProcess",
        dataType: "text",
        error: function (err) {
            outLog("错误"+err);
        },
        success: onRemoveSuccess(treeNode.name)
    })
}
function onRemoveSuccess(nodeName){
    //若当前editor中
    if($("#currtJson").text()==nodeName){
        nowJsonName = "无";
        $("#currtJson").text(nowJsonName);
        clearEditor();
    }
    outLog("删除了"+nodeName+".json文件");
}
function beforeDrag(treeId, treeNodes) {
    return false;
}
$(document).ready(function(){
	//设置json editor
	editor = new JSONEditor(container, options);
	editor.setMode("code");

    //初始化json树
    initNodeTree();
    
    //初始化button
    $( "button" ).button();
    $( "autoRefresh" ).button();
    
    //初始化窗口大小
    initView();
    
    //获取ip
    onGetPCWirelessIp();

});

function initView(){
    // var otherHeight = $(".top").height()+$(".btn_container").height()+$(".bottom").height();
    var otherHeight = document.getElementById("topId").offsetHeight+document.getElementById("btnContainerId").offsetHeight
    +document.getElementById("dividerId").offsetHeight+/*document.getElementById("bottomId").offsetHeight+*/10;


    $(".left1").css("height",document.body.scrollHeight -otherHeight-2);
    $(".left2").css("height",document.body.scrollHeight -otherHeight);
    $(".common_width").css("width",document.body.scrollWidth);
    $(".left2").css("width",document.body.scrollWidth-302);

    //监听浏览器缩放
    $(window).resize(function() {
        var width = $(this).width();
        var height = $(this).height();
        $(".left1").css("height",height-otherHeight-2);
        $(".left2").css("height",height-otherHeight);
        $(".common_width").css("width",width);
        $(".left2").css("width",width-302);
    });

}

function initNodeTree(){
    $.ajax({
        type: "post",
        data: "funcTag=getAll",
        url: "jsonFileProcess",
        dataType: "text",
        error: function (err) {
        	showToast("刷新失败");
        },
        success: onInitSuccess
    })
}

function onInitSuccess(data){
    zNodes = eval(data);//将一个string转换为json对象
    $.fn.zTree.init($("#treeDemo"), setting, zNodes);
    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
    zTree.setting.edit.showRemoveBtn = true;
    zTree.setting.edit.showRenameBtn = true;
    zTree.setting.edit.removeTitle = "remove";
    zTree.setting.edit.renameTitle = "rename";
}

//json editor
var container = document.getElementById('jsoneditor');

var options = {
    mode: 'tree',
    modes: ['code', 'tree'], // allowed modes
    onError: function (err) {
        alert(err.toString());
    },
    onModeChange: function (newMode, oldMode) {
        console.log('Mode switched from', oldMode, 'to', newMode);
    }
};
var editor ;

/**
 * 刷新，获取全部接口名称
 */
function onRefresh(){
    initNodeTree();
    outLog("refresh node tree ");
}

function onAdd() {
    //获取输入的接口名称
    var name = $("#iname").val();
    if (name == "") {
    	showToast("新增失败：请输入json文件名称");
        outLog("新增失败：请输入json文件名称");
        return;
    }
    $.ajax({
        type: "post",
        data: "funcTag=add&iname=" + name,
        url: "jsonFileProcess",
        dataType: "text",
        error: function (err) {
        	showToast("新增失败");
            outLog("错误" + err);
        },
        success: onAddSuccess
    })
}

function onAddSuccess(data){
	if(data!=""){
		showToast(data);
	}
    outLog("add success");
    onRefresh();
}

function onRemoveAll(){
    sendAjax("post","funcTag=removeAll","jsonFileProcess",
    		onRemoveAllSuccess,
    function(){
    	showToast("删除全部失败");
    });
}
function onRemoveAllSuccess(){
    onRefresh();
    clearCurrtJsonName();
    clearEditor();
    outLog("删除所有json文件！");
}

/**
 * 保存修改的json数据
 */
function onSave(){
    var requestTag = $("#currtJson").text();
    if(requestTag=="" || requestTag=="无"){
        showToast("请选择一个json文件");
    }else{
        var content = editor.getText();
        var param = "{\"requestTag\":\""+requestTag+"\",\"content\":"+content+"}";
        param=param.replace(/[\n]/ig,'');
        param=param.replace(/\s+/g,''); 
        $.ajax({
            type: "post",    // post or get
            contentType:"application/json;charset=utf-8",
            data: param,    //请求参数
            url: "jsonDataProcess",      //地址
            dataType: "text",
            error: function (err) {
            	showToast("保存失败");
                outLog("错误"+err);
            },
            success: onSaveSuccess
        });
    }
}

function onSaveSuccess(){
	showToast("保存成功");
    outLog("保存成功")
    
}

/**
 * 通过usb链接手机（使用前保证手机通过数据线连接在电脑上）
 */
function onConnMobile(){
	sendAjax("post","funcTag=usbConn","connectionProcess",null);
}

/**获取PC的无线局域网ip
 * （使用前保证pc连着无线局域网，并且没有连着其他虚拟网络，否则获取的ip地址可能不准确）
 */
function onGetPCWirelessIp(){
	sendAjax("post","funcTag=getIP","connectionProcess",
	function(data){
		var text = "<span class=\"ui-button-text\">"+data+"</span>"
		$("#btnPCWirelessIp").html(text);
//		document.getElementById('btnPCWirelessIp').label = data;
	});
}

/**
 * 修改当前接口名称
 */
function setCurrtJsonName(name){
    $("#currtJson").text(name);
    outLog("当前接口"+name);
}
/**
 * 清空当前接口名字
 */
function clearCurrtJsonName(){
	setCurrtJsonName("无");
}

/**
 * 输出日志
 */
function outLog(log){
    /*var value = $("#logContent").text();
     value = value+"<p>"+log+"</p>";
     $("#logContent").text(value);*/
}

/**
 * 发送ajax请求
 * @param type
 * @param data
 * @param url
 * @param successCallback
 */
function sendAjax(type,data,url,successCallback){
    $.ajax({
        type: type,    // post or get
        data: data,    //请求参数
        url: url,      //地址
        dataType: "text",
        error: function (err) {
            outLog("错误"+err);
        },
        success: successCallback
    })
}

function sendAjax(type,data,url,successCallback,errorCallback){
    $.ajax({
        type: type,    // post or get
        data: data,    //请求参数
        url: url,      //地址
        dataType: "text",
        error:errorCallback,
        success: successCallback
    })
}

/**
 * 将json editor清空
 */
function clearEditor(){
    editor.set("");
}

$(function() {
    $( "#accordion" ).accordion({
        heightStyle: "fill"
    });
});
$(function() {
    $( "#accordion-resizer" ).resizable({
        minHeight: 140,
        minWidth: 200,
        resize: function() {
            $( "#accordion" ).accordion( "refresh" );
        }
    });
});

var timerId;
$("#autoRefresh").click(function(){
    if (document.getElementById("autoRefresh").checked==true) {
        outLog("打开自动刷新");
//        $(this).parent().css({"background":"#dcf4fc"});
        timerId = setInterval("autoRefresh()",500); //指定1秒刷新一次
    }else{
        outLog("关闭自动刷新");
        timerId && clearInterval(timerId);
    }
});

function autoRefresh(){
    //获取全部json文件
	sendAjax("post","funcTag=getAll","jsonFileProcess",onAutoRefreshSuccess);
}

function onAutoRefreshSuccess(data){
	onInitSuccess(data);
	//根据当前json名称，判断是否存在这个文件，并且在编辑框中显示json数据
    if($("#currtJson").text()!="无"){
        var isFind = 0;
        $.each(eval(zNodes), function(sname, record) {
             $.each(record, function (name, value) {
                if(name=="name" && value==$("#currtJson").text()){
                    setCurrtJsonName(value);
                    getJsonData(value);
                    isFind=1;
                    return true;
                }
            });
            if(isFind==1){
                return true;
            }
        });
    }
}

/** 弹出浮层 */
function showPopup(message){
	var floatArea=document.getElementById("popup");
	floatArea.style.display="none";
	floatArea.innerHTML="<div id=\"floatcontent\">"+message+"</div>";
	floatArea.style.paddingLeft = "15px";
	floatArea.style.paddingRight = "15px";
	floatArea.style.paddingTop = "10px";
	floatArea.style.paddingBottom = "10px";
	floatArea.style.backgroundColor = "#000000";
	floatArea.style.color="#ffffff";
	floatArea.style.opacity = "0.8";
	floatArea.style.borderRadius="10px";    
	var height = document.body.scrollHeight
	var width = document.body.scrollWidth;
	floatArea.style.left=(document.documentElement.scrollLeft+width/2)+"px"; //scrollLeft始终都是0，why？
	floatArea.style.top=(document.documentElement.scrollTop+height/2)+"px";
	floatArea.style.width="auto";
	floatArea.style.height="auto";
	floatArea.style.display="";
}

/** 关闭浮层 */
function closePopup(){
	var floatArea=document.getElementById("popup");
	floatArea.innerHTML="";
	floatArea.style.display="none";
}

/** show toast */
function showToast(message){
	showPopup(message);
	setTimeout("closePopup()",2000);
} 