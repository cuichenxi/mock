#### ***文中链接各位根据自己项目对应修改***
--------------------------------------------------------------------------------
#### **项目管理**：
#### *sp*:(http://sp.corp.qunar.com/default.aspx)<br />

#### *jira*:(http://task.corp.qunar.com/browse/)<br />
--------------------------------------------------------------------------------
#### **发布相关**:
#### *devbds*:(http://devbds.corp.qunar.com/jenkins/)<br />
#### *bds*:(http://bds.corp.qunar.com/jenkins/)<br />
--------------------------------------------------------------------------------
#### **质量管理**:
#### *bugfree*:(http://svn.corp.qunar.com/bugfree)<br />
#### *case*:(http://bugfree.corp.qunar.com/bugfree/index.php/case)<br />
--------------------------------------------------------------------------------
#### **项目信息**:
#### *wiki*:(http://wiki.corp.qunar.com/)<br />
