/**
 * Created by WYM on 2016/4/12.
 */

/*树控件*/
var zTree;
var zNodes;
var setting = {
    view: {
        addHoverDom: addHoverDom,
        removeHoverDom: removeHoverDom,
        selectedMulti: false,
        fontCss: getFontCss
    },
    edit: {
        enable: true
    },
    data: {
        simpleData: {
            enable: true
        }
    },
    callback: {
        onClick: onClick,
        beforeRename:beforeRename,
        onRename:onRename,
        onRemove:onRemove,
        beforeDrag: beforeDrag,
        beforeCollapse: beforeCollapse,
        beforeExpand: beforeExpand,
        onCollapse: onCollapse,
        onExpand: onExpand
    }
};

//json editor
var editor ;
var container = document.getElementById('jsoneditor');
var options = {
    mode: 'tree',
    modes: ['code', 'tree'], // allowed modes
    onError: function (err) {
        alert(err.toString());
    },
    onModeChange: function (newMode, oldMode) {
        console.log('Mode switched from', oldMode, 'to', newMode);
    }
};

/**
 * 点击json文件节点，获取json数据
 * @param event
 * @param treeId
 * @param treeNode
 * @param clickFlag
 */
function onClick(event, treeId, treeNode, clickFlag) {
    //nowJsonName = treeNode.name;
    if(!treeNode.isParent && treeNode.getParentNode()!=null) {
        getJsonData(treeNode.getParentNode().name,treeNode.name);
    }
}

function getJsonData(dirName,name){
    $.ajax({
        type: "post",
        data: "requestTag=" + name+"&userId="+dirName,
        url: "getMockJson",
        dataType: "json",
        error: function (err) {
        },
        success: function(data){
            $("#currtJson").text(dirName+"："+name);
            editor.set(data);
            //if(data.indexOf("获取失败")>=0){
            //    showToast(data);
            //}else{
            //    editor.set(data);
            //}
        }
    })
}

/**
 * 重命名，目录节点，json文件节点
 * @param treeId
 * @param treeNode
 * @param newName
 * @param isCancel
 */
function beforeRename(treeId, treeNode, newName, isCancel){
    var oldName = treeNode.name;
    if(newName == oldName){
        return;
    }
    if(treeNode.isParent || treeNode.parentTId==0){//rename 目录（若目录节点没有子节点时，需要用treeNode.parentTId==0判断）
        $.ajax({
            type: "post",
            data: "funcTag=rename&oldName="+treeNode.name+"&newName="+newName,//发送到服务器的数据
            url: "dirProcess",
            dataType: "text",
            error: function (err) {
                onRenameFail(treeNode,"错误"+err,oldName);
            },
            success: function(data){
                if(data!=""){
                    onRenameFail(treeNode,data,oldName);
                }
            }
        })
    }else{
        $.ajax({
            type: "post",
            data: "funcTag=rename&dirName="+treeNode.getParentNode().name+"&oldName="+treeNode.name+"&newName="+newName,//发送到服务器的数据
            url: "jsonFileProcess",
            dataType: "text",
            error: function (err) {
                onRenameFail(treeNode,"错误"+err,oldName);
            },
            success: function(data){
                //onRenameFail(treeNode,data,oldName);
            }
        })
    }
}

function onRenameFail(treeNode,errorMsg,oldName){
    treeNode.name = oldName;
    zTree.refresh();
    showToast(errorMsg);
}

function onRename(event, treeId, treeNode, isCancel){
}

/**
 * 删除节点
 * @param event
 * @param treeId
 * @param treeNode
 */
function onRemove(event, treeId, treeNode){
    if(treeNode.getParentNode()!=null){//有父节点，则为json文件节点
        $.ajax({
            type: "post",
            data: "funcTag=remove&dir="+treeNode.getParentNode().name+"&name="+treeNode.name,
            url: "jsonFileProcess",
            dataType: "text",
            error: function (err) {
                showToast("错误"+err);
            },
            success: onRemoveSuccess(treeNode.name)
        })
    }else{//没有父节点，则为目录节点
        $.ajax({
            type: "post",
            data: "funcTag=remove&dir="+treeNode.name,
            url: "jsonFileProcess",
            dataType: "text",
            error: function (err) {
                showToast("错误"+err);
            },
            success: onRemoveSuccess(treeNode.name)
        })
    }

}
function onRemoveSuccess(nodeName){
    //若删除的目录或节点正在展示，则清空json editor
    //$("#currtJson").text()
    //clearEditor();
}
function beforeDrag(treeId, treeNodes) {
    return false;
}

function beforeCollapse(treeId, treeNode) {
    return (treeNode.collapse !== false);
}
function onCollapse(event, treeId, treeNode) {
}
function beforeExpand(treeId, treeNode) {
    $.ajax({
        type: "post",
        data: "funcTag=getChildNodes&dirName="+treeNode.name+"&parentId="+treeNode.id,
        url: "jsonFileProcess",
        dataType: "text",
        error: function (err) {
            showToast("刷新失败！")
        },
        success: function(data){
            if(data==""){
                showToast("刷新失败！")
            }else{
                //刷新当前节点的所有子节点
                zTree.removeChildNodes(treeNode);
                $.each(eval(data), function (sname, record) {
                    zTree.addNodes(treeNode, record);
                });
                showToast("刷新成功")
            }
        }
    })

    return (treeNode.expand !== false);
}
function onExpand(event, treeId, treeNode) {
}

/**
 * 鼠标经过目录节点时，添加“add”按钮
 * @param treeId
 * @param treeNode
 */
var hoverNode;
function addHoverDom(treeId, treeNode) {
    //新增按钮
    addAddBtn(treeId,treeNode);
    //刷新按钮
    addRefreshBtn(treeId,treeNode);

    hoverNode = treeNode;
};

function addAddBtn(treeId, treeNode) {
    if(treeNode.getParentNode()!=null){//只有在目录节点时才显示，add按钮
        return;
    }
    var sObj = $("#" + treeNode.tId + "_span");
    if (treeNode.editNameFlag || $("#addBtn_"+treeNode.tId).length>0) {
        return;
    }
    var addStr = "<span class='button add' id='addBtn_" + treeNode.tId
        + "' title='add json file' onfocus='this.blur();'></span>";
    sObj.after(addStr);
    var btn = $("#addBtn_"+treeNode.tId);

    if (btn) btn.bind("click", function(){
        var currtId ;
        if(treeNode.children==null){//没有子节点
            currtId = 1;
        }else{
            currtId = treeNode.children.length+1;
        }

        var dir = treeNode.name;
        var name = "f_" + currtId+"_"+getNowDate();
        $.ajax({
            type: "post",
            data: "funcTag=add&selectedDir="+dir+"&iname=" + name,
            url: "jsonFileProcess",
            dataType: "text",
            error: function (err) {
                showToast("新增失败");
                showToast("错误" + err);
            },
            success: function(data){
                if(data==""){
                    zTree.addNodes(treeNode, {id:currtId, pId:treeNode.id, name:name ,nocheck:true});
                }else{
                    showToast(data);
                }
            }
        })

        return false;
    });
};

function addRefreshBtn(treeId, treeNode) {
    if(treeNode.getParentNode()!=null){//只有在目录节点时才显示，add按钮
        return;
    }
    var sObj = $("#" + treeNode.tId + "_span");
    if (treeNode.editNameFlag || $("#refreshBtn_"+treeNode.tId).length>0) {
        return;
    }
    var addStr = "<span class='button refresh' id='refreshBtn_" + treeNode.tId
        + "' title='refresh node' onfocus='this.blur();'></span>";
    sObj.after(addStr);
    var btn = $("#refreshBtn_"+treeNode.tId);

    if (btn) btn.bind("click", function(){
        var dir = treeNode.name;
        $.ajax({
            type: "post",
            data: "funcTag=getChildNodes&dirName="+dir+"&parentId=" + treeNode.id,
            url: "jsonFileProcess",
            dataType: "text",
            error: function (err) {
                showToast("刷新失败");
            },
            success: function(data){
                if(data!=""){
                    zTree.removeChildNodes(treeNode);
                    $.each(eval(data), function (sname, record) {
                        zTree.addNodes(treeNode, record);
                    });
                    treeNode.open = true;
                    showToast("刷新成功")
                }else{
                    showToast("刷新成功");
                }
            }
        })
        return false;
    });
};

/**
 * 光标不在目录节点时，移除按钮
 * @param treeId
 * @param treeNode
 */
function removeHoverDom(treeId, treeNode) {
    $("#addBtn_"+treeNode.tId).unbind().remove();
    $("#refreshBtn_"+treeNode.tId).unbind().remove();
};

function getFontCss(treeId, treeNode) {
    return (!!treeNode.highlight) ? {color:"#A60000", "font-weight":"bold"} : {color:"#333", "font-weight":"normal"};
}

$(document).ready(function(){
    //获取用户名
    initUserId();

	//设置json editor
	editor = new JSONEditor(container, options);
	editor.setMode("code");

    //初始化json树
    initNodeTree();
    
    //初始化button
    $( "button" ).button();
    $( "autoRefresh" ).button();
    $("#iname").val("branch_"+getNowDateSimple()+"_");
    
    //初始化窗口大小
    initView();

    //初始化dialog
    initDialog();
    
    //获取ip
    //onGetPCWirelessIp();

});

/**
 * 每次刷新网页的时候，判断是否登录了
 * 登录状态显示用户名
 * 未登录跳转到login.html
 */
function initUserId(){
    $.ajax({
        type: "get",
        data: "",
        url: "userProcess",
        dataType: "text",
        error: function (err) {
        },
        success: function(data){
            if(data.indexOf("<!DOCTYPE html>")>=0){
                window.location.href="/fm/login.html";
            }else {
                $("#userId").text(data);
            }
        }
    })
}

function initView(){
    var otherHeight = document.getElementById("topId").offsetHeight+document.getElementById("btnContainerId").offsetHeight
    +document.getElementById("dividerId").offsetHeight+/*document.getElementById("bottomId").offsetHeight+*/10;

    $(".left1").css("height",document.body.scrollHeight -otherHeight-2);
    $(".left2").css("height",document.body.scrollHeight -otherHeight);
    $(".common_width").css("width",document.body.scrollWidth);
    $(".left2").css("width",document.body.scrollWidth-302);

    //监听浏览器缩放
    $(window).resize(function() {
        var width = $(this).width();
        var height = $(this).height();
        $(".left1").css("height",height-otherHeight-2);
        $(".left2").css("height",height-otherHeight);
        $(".common_width").css("width",width);
        $(".left2").css("width",width-302);
    });

}

function initNodeTree(){
    $.ajax({
        type: "post",
        data: "funcTag=getAll",
        url: "jsonFileProcess",
        dataType: "text",
        error: function (err) {
        	showToast("刷新失败");
        },
        success: onInitSuccess
    })
}

function onInitSuccess(data){
    zNodes = eval(data);//将一个string转换为json对象
    $.fn.zTree.init($("#treeDemo"), setting, zNodes);
    zTree = $.fn.zTree.getZTreeObj("treeDemo");
    zTree.setting.edit.showRemoveBtn = true;
    zTree.setting.edit.showRenameBtn = true;
    zTree.setting.edit.removeTitle = "remove";
    zTree.setting.edit.renameTitle = "rename";
}

function initDialog() {
    $("#dialog").dialog({
        autoOpen: false,
        width: 400,
        buttons: [
            {
                text: "Ok",
                click: function () {
                    $(this).dialog("close");
                    sendAjax("post", "funcTag=removeAll", "jsonFileProcess",
                        function(){
                            onRefresh(false);
                            clearCurrtJsonName();
                            clearEditor();
                        },
                        function () {
                            showToast("删除全部失败");
                        });
                }
            },
            {
                text: "Cancel",
                click: function () {
                    $(this).dialog("close");
                }
            }
        ]
    });
}

/**
 * 刷新，获取全部接口名称
 */
function onRefresh(isHasTip){
    $.ajax({
        type: "post",
        data: "funcTag=getAll",
        url: "jsonFileProcess",
        dataType: "text",
        error: function (err) {
            showToast("刷新失败");
        },
        success: function(data){
            zNodes = eval(data);//将一个string转换为json对象
            $.fn.zTree.init($("#treeDemo"), setting, zNodes);
            zTree = $.fn.zTree.getZTreeObj("treeDemo");
            if(isHasTip==false){

            }else{
                showToast("刷新成功");
            }

        }
    })
}

/**
 * 新增目录节点
 */
function onAdd() {
    //获取输入的接口名称
    var name = $("#iname").val();
    if (name == "") {
    	showToast("新增失败：请输入目录名称");
        return;
    }
    $.ajax({
        type: "post",
        data: "funcTag=add&dirName=" + name,
        url: "dirProcess",
        dataType: "text",
        error: function (err) {
        	showToast("新增失败");
        },
        success: function(data){
            if(data!=""){//添加失败
                showToast(data);
            }else {   //添加成功
                //onRefresh();
                var currtId;
                if (zTree.getNodes() == null) {
                    currtId = 1;
                } else {
                    currtId = zTree.getNodes().length + 1;
                }
                zTree.addNodes(null, {id: currtId, pId: 0, name: name});
            }
        }
    })
}

/**
 * 删除所有目录和json文件
 */
function onRemoveAll(){
    $( "#dialog" ).dialog("open");
}


/**
 * 保存修改的json数据
 */
function onSave(){
    var temp = $("#currtJson").text();
    var strs= new Array(); //定义一数组
    strs=temp.split("："); //字符分割
    var requestTag="",dirName="";
    if(strs.length==2){
        dirName=strs[0];
        requestTag=strs[1];
    }
    if(requestTag=="" || dirName==""){
        showToast("请选择一个json文件");
    }else{
        var content = editor.getText();
        var param = "{\"requestTag\":\""+requestTag+"\"," +
            "\"dirName\":\""+dirName+"\",\"content\":"+content+"}";
        param=param.replace(/[\n]/ig,'');
        $.ajax({
            type: "post",    // post or get
            contentType:"application/json;charset=utf-8",
            data: param,    //请求参数
            url: "jsonDataProcess",      //地址
            dataType: "text",
            error: function (err) {
            	showToast("保存失败");
            },
            success: onSaveSuccess
        });
    }
}

function onSaveSuccess(){
	showToast("保存成功");
}

function onLocate() {
    var dirName = getCurrtDirName();
    var jsonName = getCurrtJsonName();
    if (dirName == "" || jsonName == "") {
        showToast("当前文件不存在！")
        return;
    }
    var dirNode = zTree.getNodeByParam("name", dirName);
    if (dirNode === null) {
        showToast("当前文件不存在！")
        return;
    }
    var jsonNode = zTree.getNodeByParam("name", jsonName, dirNode);
    if (jsonNode === null) {
        showToast("当前文件不存在！")
        return;
    }
    zTree.expandNode(dirNode, true, null, null, null);//将当前目录节点展开
    jsonNode.highlight = true;   //设置高亮
    zTree.updateNode(jsonNode);
}

/**
 * 通过usb链接手机（使用前保证手机通过数据线连接在电脑上）
 */
/*function onConnMobile(){
	sendAjax("post","funcTag=usbConn","connectionProcess",null);
}*/

/**获取PC的无线局域网ip
 * （使用前保证pc连着无线局域网，并且没有连着其他虚拟网络，否则获取的ip地址可能不准确）
 */
/*function onGetPCWirelessIp(){
	sendAjax("post","funcTag=getIP","connectionProcess",
	function(data){
		var text = "<span class=\"ui-button-text\">"+data+"</span>"
		$("#btnPCWirelessIp").html(text);
	});
}*/

/**
 * 修改当前接口名称
 */
function setCurrtJsonName(name){
    $("#currtJson").text(name);
}
/**
 * 清空当前接口名字
 */
function clearCurrtJsonName(){
	setCurrtJsonName("无");
}

/**
 * 发送ajax请求
 * @param type
 * @param data
 * @param url
 * @param successCallback
 */
function sendAjax(type,data,url,successCallback){
    $.ajax({
        type: type,    // post or get
        data: data,    //请求参数
        url: url,      //地址
        dataType: "text",
        error: function (err) {
        },
        success: successCallback
    })
}

function sendAjax(type,data,url,successCallback,errorCallback){
    $.ajax({
        type: type,    // post or get
        data: data,    //请求参数
        url: url,      //地址
        dataType: "text",
        error:errorCallback,
        success: successCallback
    })
}

/**
 * 将json editor清空
 */
function clearEditor(){
    editor.set("");
}

$(function() {
    $( "#accordion" ).accordion({
        heightStyle: "fill"
    });
});
$(function() {
    $( "#accordion-resizer" ).resizable({
        minHeight: 140,
        minWidth: 200,
        resize: function() {
            $( "#accordion" ).accordion( "refresh" );
        }
    });
});

var timerId;
$("#autoRefresh").click(function(){
    if (document.getElementById("autoRefresh").checked==true) {
//        $(this).parent().css({"background":"#dcf4fc"});
        timerId = setInterval("autoRefresh()",500); //指定1秒刷新一次
    }else{
        timerId && clearInterval(timerId);
    }
});

function autoRefresh(){
    //获取全部json文件
	sendAjax("post","funcTag=getAll","jsonFileProcess",onAutoRefreshSuccess);
}

function onAutoRefreshSuccess(data){
	onInitSuccess(data);
	//根据当前json名称，判断是否存在这个文件，并且在编辑框中显示json数据
    //if($("#currtJson").text()!="无"){
     //   var isFind = 0;
     //   $.each(eval(zNodes), function(sname, record) {
     //        $.each(record, function (name, value) {
     //           if(name=="name" && value==$("#currtJson").text()){
     //               setCurrtJsonName(value);
     //               getJsonData(value);
     //               isFind=1;
     //               return true;
     //           }
     //       });
     //       if(isFind==1){
     //           return true;
     //       }
     //   });
    //}
}

/** 弹出浮层 */
function showPopup(message){
	var floatArea=document.getElementById("popup");
	floatArea.style.display="none";
	floatArea.innerHTML="<div id=\"floatcontent\">"+message+"</div>";
	floatArea.style.paddingLeft = "15px";
	floatArea.style.paddingRight = "15px";
	floatArea.style.paddingTop = "10px";
	floatArea.style.paddingBottom = "10px";
	floatArea.style.backgroundColor = "#000000";
	floatArea.style.color="#ffffff";
	floatArea.style.opacity = "0.8";
	floatArea.style.borderRadius="10px";    
	var height = document.body.scrollHeight
	var width = document.body.scrollWidth;
	floatArea.style.left=(document.documentElement.scrollLeft+width/2)+"px"; //scrollLeft始终都是0，why？
	floatArea.style.top=(document.documentElement.scrollTop+height/2)+"px";
	floatArea.style.width="auto";
	floatArea.style.height="auto";
	floatArea.style.display="";
}

/** 关闭浮层 */
function closePopup(){
	var floatArea=document.getElementById("popup");
	floatArea.innerHTML="";
	floatArea.style.display="none";
}

/** show toast */
function showToast(message){
	showPopup(message);
	setTimeout("closePopup()",2000);
}

/**
 * 获取当前时间（毫秒）
 */
function getNowDate(){
    var date=new Date();
    var month = date.getMonth()+1;
    var result=""+date.getFullYear()+month+date.getDate()+date.getHours()+date.getMinutes()+date.getSeconds()+date.getMilliseconds();
    return result;
}

function getNowDateSimple(){
    var date=new Date();
    var month = date.getMonth()+1;
    var result=""+month+date.getDate()+date.getHours()+date.getMinutes();
    return result;
}

/**
 *
 */
function getCurrtDirName(){
    var temp = $("#currtJson").text();
    var strs= new Array(); //定义一数组
    var dirName="";
    strs=temp.split("："); //字符分割
    if(strs.length==2){
        dirName=strs[0];
    }
    return dirName;
}

function getCurrtJsonName(){
    var temp = $("#currtJson").text();
    var strs= new Array(); //定义一数组
    var jsonName="";
    strs=temp.split("："); //字符分割
    if(strs.length==2){
        jsonName=strs[1];
    }
    return jsonName;
}

//退出
function onExit(){
$.ajax({
            type: "get",
            data: "",
            url: "exitProcess",
            dataType: "text",
            error: function (err) {
                showToast("退出失败:"+err.toString());
            },
            success: function(data){
            if(data.indexOf("<!DOCTYPE html>")>=0){
                            window.location.href="/fm/login.html";
                        }else {
                             showToast("退出失败！");
                        }
            }
        })

}