package qmock.web.utils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/**
 * Created by WYM on 2016/6/7.
 */
public class CookieUtils {

    public static String getUserId(HttpServletRequest request) throws UnsupportedEncodingException {
        Cookie[] cookies = request.getCookies();
        String userId = null;
        if(cookies==null){
            return null;
        }
        for (Cookie cookie : cookies) {
            String cookieName = cookie.getName();
            if ("userId".equals(cookieName)) {
                userId = URLDecoder.decode(cookie.getValue(), "UTF8");
                return userId;
            }
        }
       return null;
    }

    public static boolean exit(HttpServletRequest request,HttpServletResponse response){
        Cookie[] cookies = request.getCookies();
        if(cookies==null){
            return true;
        }
        for (Cookie cookie : cookies) {
            String cookieName = cookie.getName();
            if ("userId".equals(cookieName)) {
                cookie.setMaxAge(0);
                System.out.println("cookieUtils-exit-成功");
                response.addCookie(cookie);
                return true;
            }
        }
        return false;
    }

}
