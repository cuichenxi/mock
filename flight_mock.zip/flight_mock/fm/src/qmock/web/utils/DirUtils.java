package qmock.web.utils;

import javax.swing.*;
import java.io.File;
import java.util.ArrayList;

/**
 * Created by WYM on 2016/5/27.
 */
public class DirUtils {

    public static void deleteDir(String dir) {
        if(dir==null || dir.equals("")){
            return;
        }
        File dir1 = JsonFileUtils.getFileObjByDirName(dir);
        ArrayList<File> files = getJsonFilesByDir(dir1);
        DefaultListModel<String> listModel = JsonFileUtils.getDataModle(files);
        String[] dataNames = JsonFileUtils.getDataNames(listModel);
        if(dataNames==null || dataNames.length==0){
            dir1.delete();
            return;
        }
        for(int i=0;i<dataNames.length;i++){
            File file = new File(dir1+"/"+dataNames[i]);
            file.delete();
        }
        dir1.delete();
    }

    /**
     * 获取所有目录
     * @return
     */
    public static ArrayList<File> getAllDir(){
        File jsonFile = JsonFileUtils.getJsonBaseDir();
        ArrayList<File> filelist = new ArrayList<File>();
        if (jsonFile.exists() && jsonFile.isDirectory()) {
            File[] files = jsonFile.listFiles(); // 该文件目录下文件全部放入数组
            if (files != null && files.length > 0) {
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isDirectory()) { // 判断是文件还是文件夹
                        filelist.add(files[i]);
                    }
                }
            }
        }
        return filelist;
    }

    /**
     * 获取该文件夹里的所有json文件
     * @param dir
     * @return
     */
    public static ArrayList<File> getJsonFilesByDir(File dir) {
        ArrayList<File> filelist = new ArrayList<File>();
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles(); // 该文件目录下文件全部放入数组
            if (files != null && files.length > 0) {
                for (int i = 0; i < files.length; i++) {
                    if (!files[i].isDirectory()&&files[i].getName().endsWith(".json")) { // 判断是文件还是文件夹
                        String strFileName = files[i].getName();
                        System.out.println(strFileName);
                        filelist.add(files[i]);
                    }
                }
            }
        }
        return filelist;
    }

    /**
     * 获取该文件夹里的所有json文件
     * @param dirName 文件夹名称
     * @return
     */
    public static ArrayList<File> getJsonFilesByDir(String dirName) {
        File jsonFile = JsonFileUtils.getFileObjByDirName(dirName);
        ArrayList<File> filelist = new ArrayList<File>();
        if (jsonFile.exists() && jsonFile.isDirectory()) {
            File[] files = jsonFile.listFiles(); // 该文件目录下文件全部放入数组
            if (files != null && files.length > 0) {
                for (int i = 0; i < files.length; i++) {
                    if (!files[i].isDirectory()&&files[i].getName().endsWith(".json")) { // 判断是文件还是文件夹
                        String strFileName = files[i].getName();
                        System.out.println(strFileName);
                        filelist.add(files[i]);
                    }
                }
            }
        }
        return filelist;
    }
}
