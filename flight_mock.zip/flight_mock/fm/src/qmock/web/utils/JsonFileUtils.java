package qmock.web.utils;

import java.io.*;
import java.util.*;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;

public class JsonFileUtils {

	public static File getJsonBaseDir() {
		FileSystemView fsv = FileSystemView.getFileSystemView();
		File rootfile = fsv.getHomeDirectory();
		String dataFile = rootfile.getPath() + "/mockdata/json";
		File parent = new File(dataFile);
		if (parent != null && !parent.exists()) {
			parent.mkdirs();
		}

		return parent;
	}

    /**
     * 根据文件夹名称获取File对象
     * @param dirName
     * @return
     */
    public static File getFileObjByDirName(String dirName){
    	if(dirName==null || dirName.equals("")){
    		return null;
    	}
        FileSystemView fsv = FileSystemView.getFileSystemView();
        File rootfile = fsv.getHomeDirectory();
        String dataFile = rootfile.getPath() + "/mockdata/json/"+dirName;
        File parent = new File(dataFile);
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        return parent;
    }

	 
	public static void WriteStringToFile2(String filePath , String content) {
        try {
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(filePath),false),"utf-8"));
            bw.append(content);
            bw.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

	public static void createFile(String dirName,String fileName) {
		 File mockfile = new File (JsonFileUtils.getFileObjByDirName(dirName) +"/"+fileName);
			try {
				if(!mockfile.exists()){
					mockfile.createNewFile();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			WriteStringToFile2(mockfile.getAbsolutePath() , "{\"tip\":\"请填写json数据\"}");
	}

    /**
     * 获取所有File对象的name
     * @param data
     * @return
     */
    public static DefaultListModel<String> getDataModle(ArrayList<File> data) {
        DefaultListModel<String>  fileNames =null;
        if(data!=null&&data.size()>0){
            fileNames = new DefaultListModel<String>();
            for (File file : data) {
                fileNames.addElement(file.getName());
            }
        }
        return fileNames;
    }

    /**
     * 获取string[]格式的file name
     * @param data
     * @return
     */
    public static String []  getDataNames(DefaultListModel<String> data) {
        String [] fileNames =null;
        if(data!=null&&data.size()>0){
            fileNames = new String [data.size()] ;
            for(int i =0 ;i<data.size() ;i++){
                fileNames[i] =data.get(i);
            }
            Arrays.sort(fileNames); //按字母排序
        }
        return fileNames;
    }

    /**
     * 读取file的内容
     * 以行为单位读取文件，常用于读面向行的格式化文件
     */
    public static String readFileByLines(File file) {

        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(file),"utf-8"));
            String tempString = "";
            String resultString = "";
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                resultString = resultString + tempString;
            }
            reader.close();

            return resultString;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }

        return null;
    }

}
