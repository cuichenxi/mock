package qmock.web.user;

import com.qunar.security.QSSO;
import com.qunar.security.qsso.model.QUser;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;

/**
 * Created by WYM on 2016/6/6.
 */
public class LoginProcess extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req, resp);
    }

    protected void process(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 从post数据里中获取到token参数
        String token = request.getParameter("token");

        // 调用QSSO方法，获取QUser实例
        QUser user = QSSO.getQUser(token);

        if (null != user) {
            // 登录成功, 从user中获取用户名， 可以使用userId来标识一个qunar员工，完成后面的登录逻辑（如：setSession或者setCookie）。
            String userId = user.getUserId();
            System.out.println("user:"+userId);
            //设置cookie
            Cookie nameCookie = new Cookie("userId", URLEncoder.encode(userId, "UTF-8"));
            nameCookie.setMaxAge(60*60*12);
            response.addCookie(nameCookie);
            response.sendRedirect("/fm/index.html");
        } else {
            // 登录失败，token值非法或者过期了，（token只能verify一次，验证后就失效了）
            response.sendRedirect("/fm/login.html");
        }
    }
}
