package qmock.web.data;

import qmock.web.utils.DirUtils;
import qmock.web.utils.JsonFileUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * 对json文件的操作：获取，新增，删除（json文件，目录），
 * Created by WYM on 2016/4/11.
 */
public class JsonFileProcess extends BaseProcess {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req, resp);
    }

    protected void process(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String funcTag = req.getParameter("funcTag");
        System.out.println("funcTag:" + funcTag);
        if (funcTag == null || funcTag.length() == 0) {
            return;
        }
        if (funcTag.equals("getAll")) {//获取带目录的接口名称
            getAllJsonFiles(resp);
        }
        else if (funcTag.equals("getChildNodes")) {
            String dirName = req.getParameter("dirName");
            String parentId = req.getParameter("parentId");
            String result = getChildNodes(dirName,parentId);
            System.out.println("result-"+result);
            resp.setCharacterEncoding("UTF-8");
            PrintWriter out = resp.getWriter();
            out.write(result);
            out.close();
        }
        else if (funcTag.equals("add")) { //新增json文件
            String iname = req.getParameter("iname");
            String dirName = req.getParameter("selectedDir");
            String result = addJsonFile(dirName, iname);
            resp.setCharacterEncoding("UTF-8");
            PrintWriter out = resp.getWriter();
            out.write(result);
            out.close();

        } else if (funcTag.equals("rename")) {//修改json文件名称
            String dirName = req.getParameter("dirName");
            String oldName = req.getParameter("oldName");
            String newName = req.getParameter("newName");
            modifyJsonFileName(dirName, oldName, newName);
        } else if (funcTag.equals("remove")) {  //删除某个json文件
            String dir = req.getParameter("dir");
            if (dir == null || dir.equals("")) {
                return;
            }
            String name = req.getParameter("name");
            if (name == null || name.equals("")) {//删除dir目录，以目录里的所有文件
                deleteDir(dir);
            } else { //删除某个文件
                File file = new File(JsonFileUtils.getJsonBaseDir() + "/" + dir + "/" + name + ".json");
                if (file != null) {
                    file.delete();
                }
            }
        } else if (funcTag.equals("removeAll")) {  //删除所有json文件
            removeAll();
        }
    }

    private void deleteDir(String dir) {
       DirUtils.deleteDir(dir);
    }

    /**
     * 根据接口名字新增一个接口
     * @param iname
     */
    private String addJsonFile(String dirName,String iname) {
        ArrayList<File> data = DirUtils.getJsonFilesByDir(dirName);
        DefaultListModel<String> listModel = JsonFileUtils.getDataModle(data);
        if(listModel==null || listModel.size()==0 || (listModel.size()>0 && !listModel.contains(iname+".json"))){
            //新建json文件
            String fileName = iname + ".json";
            JsonFileUtils.createFile(dirName, fileName);
            return "";//新增成功
        }else if(listModel.contains(iname+".json")){
        	String fileName = iname + ".json";
        	return "新增失败：已存在"+fileName+"文件";
        }
		return "";
    }

    /**
     * 修改json文件名称
     * @param oldName
     * @param newName
     */
    private void modifyJsonFileName(String dirName,String oldName,String newName){
        if(dirName==null || dirName.isEmpty()){
            return;
        }
        if(oldName==null || oldName.isEmpty()){
            return;
        }
        if(newName==null || newName.isEmpty()){
            return;
        }
        oldName +=".json";
        newName +=".json";
        File oldFile = new File(JsonFileUtils.getJsonBaseDir()+"/"+dirName+"/"+oldName);
        File newFile = new File(JsonFileUtils.getJsonBaseDir()+"/"+dirName+"/"+newName);
        if (oldFile != null) {
            oldFile.renameTo(newFile);
        }
    }
    
    private void getAllJsonFiles(HttpServletResponse resp) throws IOException{
    	ArrayList<File> dir = DirUtils.getAllDir();
        DefaultListModel<String> listModel = JsonFileUtils.getDataModle(dir);
        String[] dirNames = JsonFileUtils.getDataNames(listModel);
        if(dirNames==null || dirNames.length==0){
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(int i=0;i<dirNames.length;i++){
            sb.append("{ id:").append(i+1).append(", pId:0, name:");
            sb.append("\"").append(dirNames[i]).append("\"").append(", open:false},");

            String[] jsonFileNames = getJsonFileNames(dirNames[i]);
            if(jsonFileNames==null || jsonFileNames.length==0){
            	continue;
            }
            for(int j=0;j<jsonFileNames.length;j++){
            	String pId = i+1+"";
            	String cId = j+1+"";
            	String subId = pId+cId;
            	sb.append("{ id:").append(subId).append(", pId:").append(pId).append(", name:");
                sb.append("\"").append(jsonFileNames[j].replace(".json", "")).append("\"").append(", open:true},");
            }
            
        }
        String treeJson = sb.substring(0,sb.length()-1);
        treeJson += "]";
        System.out.println("获取全部json文件-"+treeJson);
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        out.write(treeJson.toString());
        out.close();
    }
    
    /**
     * 获取一个目录中所有json文件名
     * @param dirName
     * @return
     */
    private String[] getJsonFileNames(String dirName){
    	File dir = JsonFileUtils.getFileObjByDirName(dirName);
    	ArrayList<File> files = DirUtils.getJsonFilesByDir(dir);
        DefaultListModel<String> listModel = JsonFileUtils.getDataModle(files);
        String[] dataNames = JsonFileUtils.getDataNames(listModel);
        if(dataNames!=null) {
            Arrays.sort(dataNames); //按字母排序
        }
        return dataNames;
    }
    
    /**
     * 删除所有文件
     */
    private void removeAll(){
    	ArrayList<File> dir = DirUtils.getAllDir();
        DefaultListModel<String> listModel = JsonFileUtils.getDataModle(dir);
        String[] dirNames = JsonFileUtils.getDataNames(listModel);
        if(dirNames==null || dirNames.length==0){
            return;
        }
        for(int i=0;i<dirNames.length;i++){
            String[] jsonFileNames = getJsonFileNames(dirNames[i]);
            if(jsonFileNames!=null && jsonFileNames.length>0){
            	for(int j=0;j<jsonFileNames.length;j++){
                	File file = new File(dir.get(i)+"\\"+jsonFileNames[j]);
                	file.delete();
                }
            }
            dir.get(i).delete();
        }
        
    }

    public String getChildNodes(String dirName,String parentId) {
        String result="";
        if(dirName==null || dirName.isEmpty()){
            return "";
        }
        else{
            String[] jsonFileNames = getJsonFileNames(dirName);
            if(jsonFileNames==null || jsonFileNames.length==0){
                return "";
            }
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            for(int j=0;j<jsonFileNames.length;j++){
                sb.append("{ id:").append(j+1).append(", pId:").append(parentId).append(", name:");
                sb.append("\"").append(jsonFileNames[j].replace(".json", "")).append("\"").append(", open:true},");
            }
            result = sb.substring(0,sb.length()-1);
            result += "]";
            return result;
        }
    }
}
