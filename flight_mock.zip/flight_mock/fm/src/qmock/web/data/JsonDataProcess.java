package qmock.web.data;

import qmock.web.utils.JsonFileUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * 对json数据的操作
 * 保存json数据
 */
@SuppressWarnings("serial")
public class JsonDataProcess extends BaseProcess {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}

	/**
	 * @param
	 * @param
	 * @throws javax.servlet.ServletException
	 * @throws java.io.IOException
	 */
	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		StringBuilder sb = new StringBuilder();
	    try(BufferedReader reader = request.getReader()) {
	       char[] buff = new char[1024];
	       int len;
	       while((len = reader.read(buff)) != -1) {
	         sb.append(buff,0, len);
	       }
	     }catch (IOException e) {
	       e.printStackTrace();
	     }
//	    JSONObject jobject = JSONObject.fromObject(sb.toString());//会将符合json格式的字符串给解析，不期望解析
        com.alibaba.fastjson.JSONObject jobject = com.alibaba.fastjson.JSON.parseObject(sb.toString(),com.alibaba.fastjson.parser.Feature.OrderedField);
		String requestTag = jobject.getString("requestTag");
		String dirName = jobject.getString("dirName");
		String content = jobject.getString("content");
		System.out.println("request:"+sb.toString());
		if (requestTag == null || requestTag.length() == 0 || dirName==null ||dirName.isEmpty()) {
			return;
		}
		if (requestTag != null && requestTag.length() > 0 && content != null && content.length() > 0) { // 保存本地
			File mockfile = new File(JsonFileUtils.getFileObjByDirName(dirName) + "/" + requestTag+".json");
			JsonFileUtils.WriteStringToFile2(mockfile.getAbsolutePath(), content);
		}

	}
}
