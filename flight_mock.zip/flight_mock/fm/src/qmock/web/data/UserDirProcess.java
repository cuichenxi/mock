package qmock.web.data;

import qmock.web.utils.DirUtils;
import qmock.web.utils.JsonFileUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * 对目录的操作：获取，新增，删除，重命名，复制
 * Created by WYM on 2016/5/27.
 */
public class UserDirProcess extends BaseProcess {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        process(req, resp);
    }

    public void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        String funcTag = req.getParameter("funcTag");
        System.out.println("funcTag:"+funcTag);
        if (funcTag == null || funcTag.length() == 0) {
            return;
        }
        String result="";
        if(funcTag.equals("getAll")){//获取带目录的接口名称
            getAllDir(resp);
        }
        else if(funcTag.equals("getAllDir")){ //获取全部目录数组
            result = getAllDirArray();
        }
        else if(funcTag.equals("add")) { //新增
            String dirName = req.getParameter("dirName");
            result = addDir(dirName);
        }
        else if(funcTag.equals("rename")){
            String oldName = req.getParameter("oldName");
            String newName = req.getParameter("newName");
            result = rename(oldName,newName);
        }
        else if(funcTag.equals("remove")){
            String dirName = req.getParameter("dirName");
            removeDir(dirName);
        }

        //返回处理结果
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        out.write(result);
        out.close();
    }

    public void getAllDir(HttpServletResponse resp) throws IOException {
        ArrayList<File> dir = DirUtils.getAllDir();
        DefaultListModel<String> listModel = JsonFileUtils.getDataModle(dir);
        String[] dirNames = JsonFileUtils.getDataNames(listModel);
        if(dirNames==null || dirNames.length==0){
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(int i=0;i<dirNames.length;i++){
            sb.append("{ id:").append(i+1).append(", pId:0, name:");
            sb.append("\"").append(dirNames[i]).append("\"").append(", open:true},");
        }
        String treeJson = sb.substring(0,sb.length()-1);
        treeJson += "]";
        System.out.println("获取全部目录-"+treeJson);
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        out.write(treeJson.toString());
        out.close();
    }

    public String getAllDirArray() throws IOException {
        ArrayList<File> dir = DirUtils.getAllDir();
        DefaultListModel<String> listModel = JsonFileUtils.getDataModle(dir);
        String[] dirNames = JsonFileUtils.getDataNames(listModel);
        if(dirNames==null || dirNames.length==0){
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(int i=0;i<dirNames.length;i++){
            sb.append("\"").append(dirNames[i]).append("\"").append(",");
        }
        String treeJson = sb.substring(0,sb.length()-1);
        treeJson += "]";
        return treeJson;
    }

    public String addDir(String newName) throws IOException {
        File file =new File(JsonFileUtils.getJsonBaseDir()+"/"+newName);
        //如果文件夹不存在则创建
        String result="";
        if(newName==null || newName.equals("")){
            result = "新建失败：参数为空";
        }else {
            if (!file.exists() && !file.isDirectory()) {
                System.out.println("新建文件夹：" + newName);
                file.mkdir();
            } else {
                System.out.println("失败：已存在" + newName);
                result = "新建失败：已存在" + newName;
            }
        }
        return result;
    }

    public void removeDir(String dirName){
        DirUtils.deleteDir(dirName);
    }

    public String rename(String oldName,String newName) {
        if (oldName == null || oldName.isEmpty() || newName == null || newName.isEmpty()) {
            return "重命名失败：参数为空";
        }
        if (oldName.equals(newName)) {
            return "重命名失败：名字相同";
        }
        File oldfile = new File(JsonFileUtils.getJsonBaseDir() + "/" + oldName);
        File newfile = new File(JsonFileUtils.getJsonBaseDir() + "/" + newName);
        if (!oldfile.exists()) {
            return "重命名失败：重命名文件夹不存在";
        }
        if (newfile.exists()) {//若在该目录下已经有一个文件和新文件名相同，则不允许重命名
            return "重命名失败："+newName+"已经存在！";
        }
        oldfile.renameTo(newfile);
        return "";
    }
}
