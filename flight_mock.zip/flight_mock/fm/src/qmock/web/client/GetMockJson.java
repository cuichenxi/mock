package qmock.web.client;

import qmock.web.utils.JsonFileUtils;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 获取json数据
 */
@SuppressWarnings("serial")
public class GetMockJson extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		process(req, response);
	}

	/**
	 * @param request
	 * @param response
	 * @throws javax.servlet.ServletException
	 * @throws java.io.IOException
	 */
	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String requestTag = request.getParameter("requestTag");
        String userId = request.getParameter("userId"); //区分json文件的目录
        System.out.println("requestTag："+requestTag+" userId:"+userId);

        String result="";

        if(requestTag == null || requestTag.isEmpty()){
            result= "获取失败：参数requestTag为空";
        }
        if(userId==null ||userId.isEmpty()){
            result= "获取失败：userId为空";
        }

        requestTag +=".json";
        File file = new File(JsonFileUtils.getJsonBaseDir()+"/"+userId+"/"+requestTag);
        if (file != null) {
            response.setCharacterEncoding("UTF-8");
            result = JsonFileUtils.readFileByLines(file);
        }
        PrintWriter out = response.getWriter();
        out.write(result);
        out.close();
	}

}
