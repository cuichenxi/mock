package qmock.web.client;

import qmock.web.utils.JsonFileUtils;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 将手机请求返回的数据，保存到pc/服务器 上
 */
@SuppressWarnings("serial")
public class PostMockJson extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}

	/**
	 * @param
	 * @param
	 * @throws javax.servlet.ServletException
	 * @throws java.io.IOException
	 */
	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");	    
		String requestTag = request.getParameter("requestTag");
        String userId = request.getParameter("userId");
		String content = request.getParameter("content");
        System.out.println("requestTag: "+requestTag);
        System.out.println("userId: "+userId);
        System.out.println("content: "+content);
		if (requestTag == null || requestTag.length() == 0) {
			return;
		}
		if (requestTag != null && requestTag.length() > 0 && content != null && content.length() > 0) { // 保存本地
			File mockfile = new File(JsonFileUtils.getJsonBaseDir() + "/" +userId+"/"+ requestTag+".json");
			JsonFileUtils.WriteStringToFile2(mockfile.getAbsolutePath(), content);
		}

	}
}
